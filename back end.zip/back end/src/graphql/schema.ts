/**
 * GraphQL Schema definitions for the weather activity planner API
 */
export const typeDefs = `
  """
  Root query type for all API endpoints
  """
  type Query {
    """
    Health check endpoint - returns API status
    """
    health: String!

    """
    Search for cities by name
    """
    searchCities(query: String!): [City!]!

    """
    Get weather forecast for geographic coordinates
    """
    getWeather(latitude: Float!, longitude: Float!): Weather!

    """
    Get activity recommendations based on weather
    """
    getActivityRecommendations(latitude: Float!, longitude: Float!): [ActivityRecommendation!]!
  }

  """
  Represents a geographic city location
  """
  type City {
    name: String!
    latitude: Float!
    longitude: Float!
    country: String!
  }

  """
  Current weather conditions at a specific location
  """
  type Weather {
    latitude: Float!
    longitude: Float!
    temperature: Float!
    precipitation: Float!
    windSpeed: Float!
    weatherCode: Int!
  }

  """
  Activity recommendation based on weather conditions
  """
  type ActivityRecommendation {
    activity: String!
    score: Int!
    reason: String!
  }
`;
