import { CityService } from '../services/cityService';
import { WeatherService } from '../services/weatherService';
import { ActivityService } from '../services/activityService';
import { LocationHelper } from '../utils/helpers';

const cityService = new CityService();
const weatherService = new WeatherService();
const activityService = new ActivityService();

export const resolvers = {
  Query: {
    health: (): string => {
      return 'API is running healthy';
    },

    searchCities: async (_: any, { query }: { query: string }): Promise<any[]> => {
      try {
        return await cityService.searchCities(query);
      } catch (error) {
        console.error('City search error:', error);
        throw new Error('Failed to search cities');
      }
    },

    getWeather: async (
      _: any,
      { latitude, longitude }: { latitude: number; longitude: number }
    ): Promise<any> => {
      // Validate coordinates
      if (!LocationHelper.isValidCoordinate(latitude, longitude)) {
        throw new Error('Invalid coordinates provided');
      }

      try {
        const forecast = await weatherService.getWeatherForecast(latitude, longitude);
        return {
          latitude: forecast.latitude,
          longitude: forecast.longitude,
          temperature: forecast.current.temperature_2m,
          precipitation: forecast.current.precipitation,
          windSpeed: forecast.current.wind_speed_10m,
          weatherCode: forecast.current.weather_code
        };
      } catch (error) {
        console.error('Weather fetch error:', error);
        throw new Error('Failed to retrieve weather data');
      }
    },

    getActivityRecommendations: async (
      _: any,
      { latitude, longitude }: { latitude: number; longitude: number }
    ): Promise<any[]> => {
      // Validate coordinates
      if (!LocationHelper.isValidCoordinate(latitude, longitude)) {
        throw new Error('Invalid coordinates provided');
      }

      try {
        const forecast = await weatherService.getWeatherForecast(latitude, longitude);
        const recommendations = activityService.rankActivities(forecast.current);

        return recommendations.map(rec => ({
          activity: rec.activity,
          score: rec.score,
          reason: rec.reason
        }));
      } catch (error) {
        console.error('Activity recommendation error:', error);
        throw new Error('Failed to generate activity recommendations');
      }
    }
  }
};
