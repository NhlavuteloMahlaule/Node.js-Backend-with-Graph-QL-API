import axios, { AxiosInstance, AxiosError } from 'axios';

const TIMEOUT = 10000; // 10 seconds

export const openMeteoClient: AxiosInstance = axios.create({
  baseURL: 'https://api.open-meteo.com/v1',
  timeout: TIMEOUT,
  headers: {
    'Content-Type': 'application/json'
  }
});

export const geocodingClient: AxiosInstance = axios.create({
  baseURL: 'https://geocoding-api.open-meteo.com/v1',
  timeout: TIMEOUT,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Global error handler
const handleError = (error: AxiosError) => {
  if (error.response) {
    console.error(`API Error: ${error.response.status}`, error.response.data);
  } else if (error.request) {
    console.error('No response from API:', error.request);
  } else {
    console.error('Error setting up request:', error.message);
  }
};

openMeteoClient.interceptors.response.use(response => response, handleError);
geocodingClient.interceptors.response.use(response => response, handleError);
