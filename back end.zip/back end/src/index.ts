import express, { Express, Request, Response } from 'express';
import { WeatherService } from './services/weatherService';
import { ActivityService } from './services/activityService';
import { CityService } from './services/cityService';
import { LocationHelper } from './utils/helpers';

const app: Express = express();
const PORT = process.env.PORT || 3000;

// Services
const weatherService = new WeatherService();
const activityService = new ActivityService();
const cityService = new CityService();

// Middleware
app.use(express.json());

// Health check endpoint
app.get('/health', (_req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// City search endpoint
app.get('/cities/search', async (req: Request, res: Response) => {
  try {
    const { query } = req.query;

    if (!query || typeof query !== 'string') {
      return res.status(400).json({
        error: 'City name query parameter is required'
      });
    }

    const cities = await cityService.searchCities(query);
    res.json({
      success: true,
      query,
      count: cities.length,
      results: cities
    });
  } catch (error) {
    console.error('City search error:', error);
    res.status(500).json({
      error: 'Failed to search cities',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

// Weather endpoint
app.get('/weather', async (req: Request, res: Response) => {
  try {
    const { latitude, longitude } = req.query;

    const lat = latitude ? parseFloat(latitude as string) : null;
    const lon = longitude ? parseFloat(longitude as string) : null;

    if (lat === null || lon === null) {
      return res.status(400).json({
        error: 'Latitude and longitude query parameters are required'
      });
    }

    if (!LocationHelper.isValidCoordinate(lat, lon)) {
      return res.status(400).json({
        error: 'Invalid coordinates. Latitude must be between -90 and 90, longitude between -180 and 180'
      });
    }

    const forecast = await weatherService.getWeatherForecast(lat, lon);

    res.json({
      success: true,
      data: {
        coordinates: {
          latitude: forecast.latitude,
          longitude: forecast.longitude,
          formatted: LocationHelper.formatCoordinates(lat, lon)
        },
        weather: forecast.current
      }
    });
  } catch (error) {
    console.error('Weather fetch error:', error);
    res.status(500).json({
      error: 'Failed to fetch weather',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

// Activity recommendations endpoint
app.get('/recommendations', async (req: Request, res: Response) => {
  try {
    const { latitude, longitude } = req.query;

    const lat = latitude ? parseFloat(latitude as string) : null;
    const lon = longitude ? parseFloat(longitude as string) : null;

    if (lat === null || lon === null) {
      return res.status(400).json({
        error: 'Latitude and longitude query parameters are required'
      });
    }

    if (!LocationHelper.isValidCoordinate(lat, lon)) {
      return res.status(400).json({
        error: 'Invalid coordinates provided'
      });
    }

    const forecast = await weatherService.getWeatherForecast(lat, lon);
    const recommendations = activityService.rankActivities(forecast.current);

    res.json({
      success: true,
      data: {
        location: LocationHelper.formatCoordinates(lat, lon),
        weather: forecast.current,
        recommendations: recommendations.map(rec => ({
          rank: recommendations.indexOf(rec) + 1,
          activity: rec.activity,
          score: rec.score,
          reason: rec.reason
        }))
      }
    });
  } catch (error) {
    console.error('Recommendation error:', error);
    res.status(500).json({
      error: 'Failed to generate recommendations',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

// 404 handler
app.use((_req: Request, res: Response) => {
  res.status(404).json({
    error: 'Endpoint not found',
    message: 'Please check the API documentation'
  });
});

// Error handler
app.use((error: Error, _req: Request, res: Response) => {
  console.error('Unhandled error:', error);
  res.status(500).json({
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? error.message : 'An error occurred'
  });
});

// Start server
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`\n🌤️  Weather Activity Planner API`);
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Health check: http://localhost:${PORT}/health\n`);
  });
}

export default app;
