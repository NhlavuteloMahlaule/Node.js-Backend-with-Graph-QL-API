import { City, GeocodingResponse } from '../types';
import { geocodingClient } from '../utils/apiClient';

export class CityService {
  private readonly maxResults = 10;

  /**
   * Search for cities by name
   * @param name - City name to search for
   * @returns Array of matching cities
   */
  async searchCities(name: string): Promise<City[]> {
    if (!name || name.trim().length === 0) {
      throw new Error('City name cannot be empty');
    }

    try {
      const response = await geocodingClient.get<GeocodingResponse>('/search', {
        params: {
          name: name.trim(),
          count: this.maxResults,
          language: 'en',
          format: 'json'
        }
      });

      return response.data.results || [];
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unable to reach geocoding service';
      throw new Error(`City search failed: ${errorMessage}`);
    }
  }

  /**
   * Reverse geocode coordinates to find the nearest city
   * @param latitude - Geographic latitude
   * @param longitude - Geographic longitude
   * @returns The nearest city or null if none found
   */
  async getCityByCoordinates(latitude: number, longitude: number): Promise<City | null> {
    try {
      const response = await geocodingClient.get<GeocodingResponse>('/reverse', {
        params: {
          latitude,
          longitude,
          count: 1,
          language: 'en',
          format: 'json'
        }
      });

      const results = response.data.results;
      return results && results.length > 0 ? results[0] : null;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unable to reach geocoding service';
      throw new Error(`Reverse geocoding failed: ${errorMessage}`);
    }
  }
}
