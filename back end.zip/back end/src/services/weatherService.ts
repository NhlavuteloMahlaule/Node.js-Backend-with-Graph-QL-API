import { WeatherForecast, WeatherConditions } from '../types';
import { openMeteoClient } from '../utils/apiClient';

interface CacheEntry {
  forecast: WeatherForecast;
  timestamp: number;
}

export class WeatherService {
  private cache: Map<string, CacheEntry> = new Map();
  private cacheTimeout = 30 * 60 * 1000; // 30 minutes

  private createCacheKey(latitude: number, longitude: number): string {
    return `${latitude.toFixed(4)},${longitude.toFixed(4)}`;
  }

  private isCacheValid(entry: CacheEntry): boolean {
    return Date.now() - entry.timestamp < this.cacheTimeout;
  }

  async getWeatherForecast(latitude: number, longitude: number): Promise<WeatherForecast> {
    const cacheKey = this.createCacheKey(latitude, longitude);
    const cachedEntry = this.cache.get(cacheKey);

    if (cachedEntry && this.isCacheValid(cachedEntry)) {
      return cachedEntry.forecast;
    }

    try {
      const response = await openMeteoClient.get('/forecast', {
        params: {
          latitude,
          longitude,
          current: 'temperature_2m,precipitation,weather_code,wind_speed_10m'
        }
      });

      const forecast: WeatherForecast = {
        latitude: response.data.latitude,
        longitude: response.data.longitude,
        current: response.data.current
      };

      this.cache.set(cacheKey, {
        forecast,
        timestamp: Date.now()
      });

      return forecast;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unable to reach weather service';
      throw new Error(`Failed to fetch weather forecast: ${errorMessage}`);
    }
  }

  clearCache(): void {
    this.cache.clear();
  }

  getCacheSize(): number {
    return this.cache.size;
  }
}
