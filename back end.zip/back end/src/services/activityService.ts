import { ActivityRanking, ActivityType, WeatherConditions } from '../types';

interface ScoringThresholds {
  tempCold: number;
  tempVeryCold: number;
  windStrong: number;
  windModerate: number;
  rainHeavy: number;
  rainModerate: number;
  tempHot: number;
}

export class ActivityService {
  private thresholds: ScoringThresholds = {
    tempCold: 0,
    tempVeryCold: -5,
    windStrong: 15,
    windModerate: 10,
    rainHeavy: 10,
    rainModerate: 5,
    tempHot: 35
  };

  rankActivities(weather: WeatherConditions): ActivityRanking[] {
    const activities: ActivityRanking[] = [
      {
        activity: ActivityType.SKIING,
        score: this.scoreSkiing(weather),
        reason: this.getSkiingReason(weather)
      },
      {
        activity: ActivityType.SURFING,
        score: this.scoreSurfing(weather),
        reason: this.getSurfingReason(weather)
      },
      {
        activity: ActivityType.OUTDOOR_SIGHTSEEING,
        score: this.scoreOutdoor(weather),
        reason: this.getOutdoorReason(weather)
      },
      {
        activity: ActivityType.INDOOR_ACTIVITY,
        score: this.scoreIndoor(weather),
        reason: 'Perfect day to explore museums, restaurants, or entertainment venues'
      }
    ];

    return activities.sort((a, b) => b.score - a.score);
  }

  private scoreSkiing(weather: WeatherConditions): number {
    let score = 5;

    if (weather.temperature_2m < this.thresholds.tempVeryCold) score += 2;
    if (weather.temperature_2m < this.thresholds.tempCold) score += 3;

    const snowWeatherCodes = [71, 73, 75, 77, 85, 86];
    if (snowWeatherCodes.includes(weather.weather_code)) score += 3;

    if (weather.precipitation > this.thresholds.rainModerate) score += 2;

    return Math.min(10, score);
  }

  private getSkiingReason(weather: WeatherConditions): string {
    if (weather.temperature_2m < -5) return 'Excellent snow conditions!';
    if (weather.temperature_2m < 0) return 'Good snow coverage expected';
    return `Skiing conditions possible with temp at ${weather.temperature_2m}°C`;
  }

  private scoreSurfing(weather: WeatherConditions): number {
    let score = 4;

    if (weather.wind_speed_10m > this.thresholds.windStrong) score += 4;
    else if (weather.wind_speed_10m > this.thresholds.windModerate) score += 2;

    if (weather.precipitation < this.thresholds.rainModerate) score += 1;

    return Math.min(10, score);
  }

  private getSurfingReason(weather: WeatherConditions): string {
    if (weather.wind_speed_10m > 15) return 'Perfect wave conditions!';
    if (weather.wind_speed_10m > 10) return 'Decent waves forming';
    return `Winds at ${weather.wind_speed_10m} km/h may create challenging conditions`;
  }

  private scoreOutdoor(weather: WeatherConditions): number {
    let score = 8;

    if (weather.precipitation > 0) score -= 3;
    if (weather.precipitation > this.thresholds.rainHeavy) score -= 2;

    if (weather.temperature_2m < -10) score -= 2;
    if (weather.temperature_2m > this.thresholds.tempHot) score -= 2;

    return Math.max(1, score);
  }

  private getOutdoorReason(weather: WeatherConditions): string {
    if (weather.precipitation > 10) return 'Heavy rain expected - consider staying indoors';
    if (weather.temperature_2m > 35) return 'Extreme heat - plan for early morning or evening activities';
    if (weather.temperature_2m < -10) return 'Extreme cold - bundle up well';
    if (weather.precipitation > 0) return 'Some rain expected - bring an umbrella';
    return 'Great weather for outdoor exploration';
  }

  private scoreIndoor(weather: WeatherConditions): number {
    return 6;
  }
}
