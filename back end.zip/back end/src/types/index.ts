export enum ActivityType {
  SKIING = 'SKIING',
  SURFING = 'SURFING',
  OUTDOOR_SIGHTSEEING = 'OUTDOOR_SIGHTSEEING',
  INDOOR_ACTIVITY = 'INDOOR_ACTIVITY'
}

export interface WeatherConditions {
  temperature_2m: number;
  precipitation: number;
  weather_code: number;
  wind_speed_10m: number;
}

export interface WeatherForecast {
  latitude: number;
  longitude: number;
  current: WeatherConditions;
}

export interface ActivityRanking {
  activity: ActivityType;
  score: number;
  reason: string;
}

export interface City {
  name: string;
  latitude: number;
  longitude: number;
  country: string;
}

export interface GeocodingResponse {
  results: City[];
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}
